import UIKit

//Soru1: parametre olarak girilen kilometreyi mile dönüştürdükten sonra geri döndüren bir metod yazınız. Mile = Km x 0.621
//Soru2: kenarları parametre olarak girilen ve geri döndüren dikdörtgenin alanını hesaplayan bir metod yazınız.(Çözüldü)
//Soru3: parametre olarak girilen sayının faktoriyel değerini hesaplayıp geri döndüren metodu yazınız.
//Soru4: parametre olarak girilen kelime içinde kaç tane e harfi olduğunu gösteren metod yazınız.
//Soru5: parametre olarak girilen kenar sayısına göre her bir iç açıyı hesaplayıp sonucu geri getiren methodu yazın. iç açılar toplamı = ((Kenar sayısı - 2)*180)/kenar sayısı
//Soru6: parametre olarak girilen gün sayısına göre maaş hesabı yapan ve elde edilen değeri döndüren methodu yazınız. 1 günde 8 saat çalışabilir, çalışma saat ücreti; 40 TL, mesai saati ücreti; 80 TL, 150 saat üzeri mesai sayılır.
//Soru7: parametre olarak girilen otopark süresine göre otopark ücreti hesaplayarak geri döndüren methodu yazınız. 1 saat ücreti 50 TL, 1 saat aşımından sonra her saat için 10 TL'dir.

//1nci sorunun çözümü

class Fonksiyonlar1 {
    func donusum(km:Double) -> Double {
        let mil = km * 0.621
        return mil
    }
}
let d = Fonksiyonlar1()
let donusumSonucu = d.donusum(km: 3.4) //double olarak parametre girdiğim için herhangi bir ondalık sayı ile dönüşüm yapıp ekrana yazmasını istedim. Eğer tam sayı girilecekse tam sayının yanına 0 yazılarak ya da direk tam sayı olarak da yazılarak işlemler yapılabilir.
print ("Dönüşüm sonucu : \(donusumSonucu)")

//2nci sorunun çözümü

class Fonksiyonlar2 {

    func alanHesapla(kisaKenar:Int, uzunKenar:Int){
      let alanHesabi = kisaKenar * uzunKenar
       print ("Alan Hesabı : \(alanHesabi)")
    }
}

let f = Fonksiyonlar2()
f.alanHesapla(kisaKenar: 7, uzunKenar: 8)
//ben 7 ve 8 olarak giriş yaptım. Bunu isteğe göre farklı tam sayılar olarak da girebiliriz. Kenar uzunluğu olduğu için ondalık sayı olmaz diye double yerine, ınt olarak değişken tanımladım.



//3ncü sorunun çözümü

class Fonksiyonlar3 {
    func faktoriyelHesapla(n: Int) -> Int {
        var sonuc = 1
        for i in 1...n {
            sonuc *= i
        }
        return sonuc
    }
}

let fonksiyonlar = Fonksiyonlar3()
let sonuc = fonksiyonlar.faktoriyelHesapla(n: 6)  //faktöriyeli hesaplanacak olan sayıyı dışarıdan 6 olarak girdim, istenilen herhangi bir tam sayı da girilebilirdi.
print("\(sonuc)")



//4ncü sorunun çözümü
class Fonksiyonlar4 {
    func eHarfiSayisi(kelime:String){
        var sayac = 0
        for harf in kelime {
            if harf == "e" || harf == "E" {
                sayac = sayac + 1 }
        }
        print ("Girilen kelimedeki e/E harf sayısı :\(sayac)")
    }
   
}
 let harfSayisi = Fonksiyonlar4()
harfSayisi.eHarfiSayisi(kelime: "Erzincanlı Erhan")



//5nci sorunun çözümü
class Fonksiyon5 {
    func icAcilarinToplami(kacKenarli: Int) -> Int {
        let aciToplami = Int((kacKenarli - 2) * 180) / Int(kacKenarli)
        return aciToplami
    }
}

let f5 = Fonksiyon5().icAcilarinToplami(kacKenarli: 5)
print ("Çokgenin iç açıları toplamı : \(f5 * 5)")


//parametre olarak ben ınt yazan alana 5 yazdım ve sonuç olarak 540 buldu. Buraya istersek let ve print içerisinde yer alan 5 rakamlarını değiştirerek, 3-4-7 gibi farklı rakamlar ya da sayılar da girebilir, buna göre bir sonuç bulabiliriz. Ben çokgen olarak yazdırmak istedim, özel ismi olan bir çokgen yazdırmak istemeyebiliriz diye, genel ismi kullandım. Eğer 5 yerine 3 yazacaksak çokgen yerlerini üçgen olarak da değiştirebiliriz.


//6ncı sorunun çözümü
class Fonksiyonlar6 {
    let normalCalismaSaatiUcreti = 40
    let mesaiSaatiUcreti = 80
    let maksimumMesaiSaat = 150
    let calismaSaati = 8
    
    func maasHesaplama(gunSayisi: Int) -> Int {
        var toplamMaas = 0
        
        for _ in 1...gunSayisi {
            toplamMaas += calismaSaati * normalCalismaSaatiUcreti
            
            if toplamMaas > maksimumMesaiSaat * mesaiSaatiUcreti {
                toplamMaas += calismaSaati * mesaiSaatiUcreti
            }
        }
        
        return toplamMaas
    }
}

let fonksiyonlar6 = Fonksiyonlar6()
let gunSayisi = 29
// Ben mesai saati ücreti hesaplaması için 29 olarak gün ekledim, ama isteyenler burada yazan 29 yazısını farklı bir sayı ile değiştirebilir.
let maasHesabi = fonksiyonlar6.maasHesaplama(gunSayisi: gunSayisi)
print("Toplam maaş : \(maasHesabi) TL")





//7nci sorunun çözümü
class Fonksiyonlar7 {
    let ilkSaatUcreti = 50
    let ekSaatUcreti = 10
    
    func hesaplaUcret(sure: Int) -> Int {
        guard sure > 0 else {
            return 0 
        }
        
        var toplamUcretHesapla = 0
        
        for _ in 1...(sure / 60) {
            toplamUcretHesapla += ekSaatUcreti
        }
        
        if sure <= 60 {
            return ilkSaatUcreti
        } else {
            return ilkSaatUcreti + toplamUcretHesapla
        }
    }
}

let otopark = Fonksiyonlar7()
let sure = 130
//ben buraya 130 dakika olarak süre girdim, fakat isteyenler süreyi kendilerine göre ayarlayabilirler.
let toplamOdenecekUcret = otopark.hesaplaUcret(sure: sure)
print("Otopark ücreti : \(toplamOdenecekUcret) TL")























